bookcategory.xml -
<?xml version="1.0" encoding="UTF-8"?>
<Bookstore>
    <Yoga>
        <Book>
            <Book_Title>The Heart of Yoga</Book_Title>
            <Book_Author>V.Desikachar</Book_Author>
            <Book_Price>640</Book_Price>
        </Book>
        <Book>
            <Book_Title>Light on Yoga</Book_Title>
            <Book_Author>B.K.Iyengar</Book_Author>
            <Book_Price>750</Book_Price>
        </Book>
    </Yoga>
    <Story>
        <Book>
            <Book_Title>To Kill a Mockingbird</Book_Title>
            <Book_Author>Harper Lee</Book_Author>
            <Book_Price>12.99</Book_Price>
        </Book>
        <Book>
            <Book_Title>Harry potter</Book_Title>
            <Book_Author>J.K.Roy</Book_Author>
            <Book_Price>599</Book_Price>
        </Book>
    </Story>
    <Technical>
        <Book>
            <Book_Title>Handbook of Agile Software</Book_Title>
            <Book_Author>Robert Martin</Book_Author>
            <Book_Price>299</Book_Price>
        </Book>
        <Book>
            <Book_Title>Object-Oriented Software</Book_Title>
            <Book_Author>John Vlissides</Book_Author>
            <Book_Price>29</Book_Price>
        </Book>
    </Technical>
</Bookstore>