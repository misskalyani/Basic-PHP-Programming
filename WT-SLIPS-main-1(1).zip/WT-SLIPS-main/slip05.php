<?xml-stylesheet type="text/css" href="item.css" version = "1.0"?>
<Appliances>      
      <Item>
           <ItemName>Smartphone</ItemName>
           <ItemPrice>15000</ItemPrice> 
           <Quantity>300</Quantity>
     </Item>
     <Item>
           <ItemName>Toaster</ItemName>
           <ItemPrice>11000</ItemPrice>
           <Quantity>370</Quantity>
     </Item>
     <Item>
           <ItemName>Refrigerator</ItemName>
           <ItemPrice>65000</ItemPrice>
           <Quantity>500</Quantity>
     </Item>
     <Item>
           <ItemName>Dishwasher</ItemName>
           <ItemPrice>66000</ItemPrice>
           <Quantity>400</Quantity>
     </Item>
     <Item>
           <ItemName>Washing Machine</ItemName>
           <ItemPrice>45000</ItemPrice>
           <Quantity>250</Quantity>
     </Item>
</Appliances>

iten.css
A{
    display:flex;
    width:200px;
    border:2px solid white;
}
iname{
      display:block;
      padding:5px;
      color:red;
      font-family:copperplate Gothic Light;
      font-size:16pt;
      font:bold;
}
price{
      padding:5px;
      color:yellow;
      font-family:Arial;
      font-size:12pt;
      font:bold;
}
quantity{
      padding:5px;
      color:green;      
}
*{
      background-color:black;
}